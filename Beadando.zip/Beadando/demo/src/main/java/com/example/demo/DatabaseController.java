package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import java.net.PortUnreachableException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DatabaseController implements Initializable {
    Connection con = null;
    PreparedStatement st = null;
    ResultSet rs = null;

    @FXML
    private Button btnClear;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnSave;

    @FXML
    private Button btnUpdate;

    @FXML
    private TextField markaText;

    @FXML
    private TextField tipusText;

    @FXML
    private TextField evjaratText;

    @FXML
    private TextField kivitelText;

    @FXML
    private TextField arText;

    @FXML
    private ChoiceBox uzemanyagBox;

    @FXML
    private TableColumn<Database, String> cMarka;

    @FXML
    private TableColumn<Database, String> cTipus;

    @FXML
    private TableColumn<Database, String> cKivitel;

    @FXML
    private TableColumn<Database, Integer> cEvjarat;

    @FXML
    private TableColumn<Database, String> cUzemanyag;

    @FXML
    private TableColumn<Database, Integer> cAr;

    @FXML
    private TableView<Database> table;
    int id = 0;

    public void showCars(){
        ObservableList<Database> list = getCars();
        table.setItems(list);
        cMarka.setCellValueFactory(new PropertyValueFactory<Database,String >("marka"));
        cTipus.setCellValueFactory(new PropertyValueFactory<Database, String>("tipus"));
        cEvjarat.setCellValueFactory(new PropertyValueFactory<Database, Integer>("evjarat"));
        cKivitel.setCellValueFactory(new PropertyValueFactory<Database,String>("kivitel"));
        cUzemanyag.setCellValueFactory(new PropertyValueFactory<Database,String>("uzemanyag"));
        cAr.setCellValueFactory(new PropertyValueFactory<Database,Integer>("ar"));
    }

    @FXML
    void clearCar(ActionEvent event){

    }

    @FXML
    void createCar(ActionEvent event){
        String insert = "INSERT INTO cars (marka, tipus, evjarat, kivitel, uzemanyag, ar) VALUES  (?, ?, ?, ?, ?, ?)";
        con = Connection.getCon();
        try {
            st = con.prepareStatement(insert);
            st.setString(1, markaText.getText());
            st.setString(2,tipusText.getText());
            st.setInt(3,evjaratText.getText());
            st.setString(4,kivitelText.getText());
            st.setString(5,uzemanyagBox.getValue());
            st.setInt(6,arText.getText());
            st.executeUpdate();
            showCars();
        }catch (SQLException e){
            throw new RuntimeException(e);
        }

    }

    @FXML
    void getData(MouseEvent event){
        Database data = table.getSelectionModel().getSelectedItem();
        id = data.getId();
        markaText.setText(data.getMarka());
        tipusText.setText(data.getTipus());
        evjaratText.setText(data.getEvjarat());
        kivitelText.setText(data.getKivitel());
        uzemanyagBox.setItems(data.getUzemanyag());
        arText.setText(data.getAr());
        btnSave.setDisable(true);

    }

    @FXML
    void deleteCar(ActionEvent event){

    }

    @FXML
    void updateCar(ActionEvent event){
        String update = "UPDATE cars SET marka = ?, tipus = ?, evjarat = ?, kivitel = ?, uzemanyag = ?, ar = ? WHERE id = ?";
        con = Connection.getCon();
        try {
            st = con.prepareStatemant(update);
            st.setString(1, markaText.getText());
            st.setString(2, tipusText.getText());
            st.setInt(3, evjaratText.getText());
            st.setString(4, kivitelText.getText());
            st.setString(5, uzemanyagBox.getValue());
            st.setString(6, arText.getText());
            st.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        showCars();

    }

    public ObservableList<Database> getCars(){
        ObservableList<Database> cars = FXCollections.observableArrayList();

        String query = "SELECT * FROM cars";
        con = Connection.getCon();
        try {
            st = con.prepareStatemant(query);
            rs = st.executeQuery();
            while(rs.next()){
                Database st = new Database();
                st.setId(rs.getInt("id"));
                st.setMarka(rs.getString("marka"));
                st.setTipus(rs.getString("tipus"));
                st.setEvjarat(rs.getInt("evjarat"));
                st.setKivitel(rs.getString("kivitel"));
                st.setUzemanyag(rs.getString("uzemanyag"));
                st.setAr(rs.getInt("marka"));
                cars.add(st);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return cars;
    }
}

